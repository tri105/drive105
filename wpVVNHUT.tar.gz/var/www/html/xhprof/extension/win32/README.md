XHProf windows builds
===

More information
-------------------------
Visit my blog www.phpfluesterer.de to get in contact with me if you have trouble building XHProf on windows or if you're looking for the latest windows builds.


Latest windows builds
-------------------------
http://www.phpfluesterer.de/projekte/open-source-software-projekte/xhprof-php-extension/xhprof-fur-windows-aktuelle-windows-builds/